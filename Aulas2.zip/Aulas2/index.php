<?php

require_once "Controladores/plantillaC.php";  



$plantilla= new Plantilla();
$plantilla-> LlamarPlantilla();