  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">




      <ul class="sidebar-menu">

        <li>          
          <a href="#"><!-- aqui se coloca la ruta de esa ventana de inicio  -->
            <i class="fa fa-home"></i>
            <span>Inicio</span>
          </a>
        </li>
        
         <li>          
          <a href="#">
            <i class="fa fa-users"></i>
            <span>usuarios</span>
          </a>
        </li>


         <li>          
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Estudiantes</span>
          </a>
        </li>

         <li>          
          <a href="#">
            <i class="fa fa-graduation-cap"></i>
            <span>materias</span>
          </a>
        </li>

         

      </ul>



    </section>
    <!-- /.sidebar -->
  </aside>