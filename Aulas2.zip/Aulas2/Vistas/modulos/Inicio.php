<div class="content-wrapper">
	
	<selection class="content-header">

		<h1>Colegio LosPollitos</h1>

	</selection>

	<section class="content">

		<div class="box">

			<div class="box-body">
				
			</div>
			
		</div>
		

	</section>
</div>